How to Test (SQA Aspects)
✅ Check UI responsiveness on different screen sizes
✅ Validate form fields for empty inputs
✅ Test correct vs incorrect login credentials
✅ Ensure proper error messages appear

Would you like me to add test cases for SQA testing? 🚀